import React from 'react';
import { ExpoConfigView } from '@expo/samples';
import { SectionList, Image, StyleSheet, Text, View,TouchableOpacity } from 'react-native';
import { Constants } from 'expo';

export default class SettingsScreen extends React.Component {

  constructor(props){
    super(props);
    //const foo = this.props;
    //console.log('From Settings Screen');
    //console.log(this.props);
  }

  static navigationOptions = {
    title: 'IW Profile',
  };

  /*
  render() {
    return <ExpoConfigView />;
  }
  */

 render() {
  //console.log(this.props);
  const { manifest } = Constants;
  const claimDetails = this.props.navigation.state.params.claimDetails;
  //console.log('setings agains');
  //console.log(claimDetails);
  const physicalAddress = claimDetails.claim.injuredWorker.physicalAddress.line1 + ',' +
                         claimDetails.claim.injuredWorker.physicalAddress.line2 + ',' +
                         claimDetails.claim.injuredWorker.physicalAddress.suburb + ',' +
                         claimDetails.claim.injuredWorker.physicalAddress.postCode + ',' +
                         claimDetails.claim.injuredWorker.physicalAddress.state;

  const employerAddress = claimDetails.claim.employer.businessAddress.line1 + ',' +
                         claimDetails.claim.employer.businessAddress.line2 + ',' +
                         claimDetails.claim.employer.businessAddress.suburb + ',' +
                         claimDetails.claim.employer.businessAddress.postCode + ',' +
                         claimDetails.claim.employer.businessAddress.state;
  const sections = [
    { data: [{ value: claimDetails.claim.injuredWorker.firstName }], title: 'First Name' },
    { data: [{ value: claimDetails.claim.injuredWorker.lastName }], title: 'Last Name' },
    { data: [{ value: claimDetails.claim.injuredWorker.dateOfBirth}], title: 'DOB' },
    { data: [{ value: claimDetails.claim.injuredWorker.phoneNumber}], title: 'IW Phone Number' },
    { data: [{ value: physicalAddress }], title: 'IW Physical Address' },
    { data: [{ value: claimDetails.claim.employer.organisationName }], title: 'Employer (Org Name)' },
    { data: [{ value: claimDetails.claim.employer.phoneNumber }], title: 'Employer Phone Number' },
    { data: [{ value: claimDetails.claim.employer.email }], title: 'Employer Email' },
    { data: [{ value: employerAddress }], title: 'Employer Address' }
  ];

  return (
    <SectionList
      style={styles.container}
      renderItem={this._renderItem}
      renderSectionHeader={this._renderSectionHeader}
      stickySectionHeadersEnabled={true}
      keyExtractor={(item, index) => index}
      ListHeaderComponent={ListHeader(this.props)}
      ListFooterComponent = {ListFooter(this.props)}
      sections={sections}
    />
  );
}
_renderSectionHeader = ({ section }) => {
  return <SectionHeader title={section.title} />;
};

_renderItem = ({ item }) => {
  if (item.type === 'color') {
    return (
      <SectionContent>
        {item.value && <Color value={item.value} />}
      </SectionContent>
    );
  } else {
    return (
      <SectionContent>
        <Text style={styles.sectionContentText}>
          {item.value}
        </Text>
      </SectionContent>
    );
  }
};

  
}

const ListHeader = (props) => {
  const { manifest } = Constants;

  return (
    <View style={styles.titleContainer}>
      <View style={styles.titleIconContainer}>
        <AppIconPreview iconUrl={manifest.iconUrl} />
      </View>

      <View style={styles.titleTextContainer}>
        <Text style={styles.nameText} numberOfLines={1}>
         {props.navigation.state.params.claimDetails.claim.injuredWorker.firstName} &nbsp;
         {props.navigation.state.params.claimDetails.claim.injuredWorker.lastName} 
        </Text>

        <Text style={styles.slugText} numberOfLines={1}>
          ...
        </Text>

        <Text style={styles.descriptionText}>
          {props.navigation.state.params.claimDetails.claim.injuredWorker.physicalAddress.state}
        </Text>
      </View>
    </View>
  );
};
const ListFooter = (props) => {

  return (
   <TouchableOpacity style={styles.buttonContainer} onPress={() => props.navigation.navigate("Login",{"something":35})}>
            <Text style={styles.buttonText}>SIGN OUT</Text>
   </TouchableOpacity>
  );
};

const SectionHeader = ({ title }) => {
  return (
    <View style={styles.sectionHeaderContainer}>
      <Text style={styles.sectionHeaderText}>
        {title}
      </Text>
    </View>
  );
};

const SectionContent = props => {
  return (
      <View style={styles.sectionContentContainer}>
        {props.children}
      </View>
  );
};

const AppIconPreview = ({ iconUrl }) => {
  if (!iconUrl) {
    iconUrl =
      'https://s3.amazonaws.com/exp-brand-assets/ExponentEmptyManifest_192.png';
  }

  return (
    <Image
      source={require('../assets/images/robyn.jpg')}
      style={{ width: 64, height: 64 }}
      resizeMode="cover"
    />
  );
};

const Color = ({ value }) => {
  if (!value) {
    return <View />;
  } else {
    return (
      <View style={styles.colorContainer}>
        <View style={[styles.colorPreview, { backgroundColor: value }]} />
        <View style={styles.colorTextContainer}>
          <Text style={styles.sectionContentText}>
            {value}
          </Text>
        </View>
      </View>
    );
  }
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  titleContainer: {
    paddingHorizontal: 15,
    paddingTop: 15,
    paddingBottom: 15,
    flexDirection: 'row',
  },
  titleIconContainer: {
    marginRight: 15,
    paddingTop: 2,
  },
  sectionHeaderContainer: {
    backgroundColor: '#fbfbfb',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: '#ededed',
  },
  sectionHeaderText: {
    fontSize: 14,
  },
  sectionContentContainer: {
    paddingTop: 8,
    paddingBottom: 12,
    paddingHorizontal: 15,
  },
  sectionContentText: {
    color: '#808080',
    fontSize: 14,
  },
  nameText: {
    fontWeight: '600',
    fontSize: 18,
  },
  slugText: {
    color: '#a39f9f',
    fontSize: 14,
    backgroundColor: 'transparent',
  },
  descriptionText: {
    fontSize: 14,
    marginTop: 6,
    color: '#4d4d4d',
  },
  colorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  colorPreview: {
    width: 17,
    height: 17,
    borderRadius: 2,
    marginRight: 6,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: '#ccc',
  },
  colorTextContainer: {
    flex: 1,
  },
  buttonContainer : {
    backgroundColor : '#2980b9',
    marginTop : 15,
    paddingVertical : 15
  },
  buttonText : {
    textAlign : 'center',
    color : '#FFFFFF',
    fontWeight: '700'
  }
});
