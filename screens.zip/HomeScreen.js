import React from 'react';
import {
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Touchable from 'react-native-platform-touchable';
import { WebBrowser } from 'expo';

import { MonoText } from '../components/StyledText';
//import MainTabNavigator from '../navigation/MainTabNavigator';
import {StackNavigator} from 'react-navigation';

export default class HomeScreen extends React.Component {
  
  constructor(props){
    super(props);
    const claimData = this.props.navigation.state.params.claimDetails.claim;
    const lastPayment = claimData.lastPayment;
    const nextPayment = claimData.nextPayment;
    const nextAppointment = claimData.nextAppointment;
    const IWFirstName = claimData.injuredWorker.firstName;
    this.state = {
      screenProps: props,
      claimDetails : this.props.navigation.state.params.claimDetails,
      lastPayment : lastPayment,
      nextPayment : nextPayment,
      nextAppointment : nextAppointment,
    };
   //console.log('From Home Screen');
   //console.log(this.props);
  }
  

  static navigationOptions = {
    header: null,
    gesturesEnabled: false,
  };

  render() {
    return (
      <View style={styles.container}>
        <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
          <View style={styles.welcomeContainer}>
            <Image
              source={
                __DEV__
                  ? require('../assets/images/allianz-logo.jpg')
                  : require('../assets/images/allianz-logo.jpg')
              }
              style={styles.welcomeImage}
            />
          </View>

          <View style={styles.getStartedContainer}>

            <Text style={styles.getStartedText}>Policy Number -{} </Text>

            <View style={[styles.codeHighlightContainer, styles.homeScreenFilename]}>
              <MonoText style={styles.codeHighlightText}>{this.state.claimDetails.claim.policy.policyNumber}</MonoText>
            </View>

            <Text style={styles.getStartedText}>Your Claim Number -{} </Text>

            <View style={[styles.codeHighlightContainer, styles.homeScreenFilename]}>
              <MonoText style={styles.codeHighlightText}>{this.state.claimDetails.claim.claimNumber}</MonoText>
            </View>

            <Text style={styles.getStartedText}>Date of Injury -{} </Text>

            <View style={[styles.codeHighlightContainer, styles.homeScreenFilename]}>
              <MonoText style={styles.codeHighlightText}>{this.state.claimDetails.claim.dateOfInjury}</MonoText>
            </View>

            <Text style={styles.getStartedText}>
              Claim Status - {this.state.claimDetails.claim.claimStatus}
            </Text>
          </View>
          
          <View  style={styles.optionsTC}>
              <Text style={styles.optionsTitleText}>
                    Notifications
              </Text>
           </View>
        
        <Touchable
          style={styles.option}
          background={Touchable.Ripple('#ccc', false)}
          onPress={this._handleHelpPress}>
          <View style={{ flexDirection: 'row' }}>
            <View style={styles.optionIconContainer}>
              <Image
                source={require('../assets/images/hello.png')}
                resizeMode="contain"
                fadeDuration={0}
                style={{ width: 20, height: 20, marginTop: 10 }}
              />
            </View>
            <View style={styles.optionTextContainer}>
              <Text style={styles.optionText}>
                    Hello {this.state.IWFirstName}, How are you feeling ?
              </Text>
              <Text style={styles.optionText}>
                    Rate today's pain level now.
              </Text>
            </View>
            <View style={styles.optionIconContainerR}>
                <Ionicons name="ios-arrow-forward" size={22} color="#ddd" />    
            </View>
           
          </View>
        </Touchable>

        <Touchable
          background={Touchable.Ripple('#ccc', false)}
          style={styles.option}
          onPress={this._handlePressSlack}>
          <View style={{ flexDirection: 'row' }}>
            <View style={styles.optionIconContainer}>
              <Image
                source={require('../assets/images/dollar.jpg')}
                resizeMode="contain"
                fadeDuration={0}
                style={{ width: 20, height: 20, marginTop: 10 }}
              />
            </View>
            <View style={styles.optionTextContainer}>
              {this._renderNextPayment()}
            </View>
          </View>
        </Touchable>

        <Touchable
          style={styles.option}
          background={Touchable.Ripple('#ccc', false)}
          onPress={() => this.onGetAppointmentsPress(this.props)}>
          <View style={{ flexDirection: 'row' }}>
            <View style={styles.optionIconContainer}>
              <Image
                source={require('../assets/images/hospital.png')}
                resizeMode="contain"
                fadeDuration={0}
                style={{ width: 20, height: 20, marginTop: 10 }}
              />
            </View>
            <View style={styles.optionTextContainer}>
                {this._renderNextAppointment()}
            </View>
            <View style={styles.optionIconContainerR}>
              <Ionicons name="ios-arrow-forward" size={22} color="#ddd" />
            </View>
          </View>
        </Touchable>

         <Touchable
          style={styles.option}
          background={Touchable.Ripple('#ccc', false)}
          onPress={() => this.onImageUploadPress(this.props)}>
          <View style={{ flexDirection: 'row' }}>
            <View style={styles.optionIconContainer}>
              <Image
                source={require('../assets/images/MedCert.png')}
                resizeMode="contain"
                fadeDuration={0}
                style={{ width: 20, height: 20, marginTop: 10 }}
              />
            </View>
            <View style={styles.optionTextContainer}>
              <Text style={styles.optionText}>
                   Please upload your Med Cert
              </Text>
              <Text style={styles.optionText}>
                   Document please.
              </Text>
            </View>
            <View style={styles.optionIconContainerR}>
                <Ionicons name="ios-arrow-forward" size={22} color="#ddd" />
            </View>
          </View>
        </Touchable>
      
        </ScrollView>
        
        <View style={styles.tabBarInfoContainer}>
              <TouchableOpacity onPress={() => this.onImageUploadPress(this.props)} style={styles.helpLink}>
              <Text style={styles.helpLinkText}>Upload Document</Text>
            </TouchableOpacity>
        </View>

      </View>
    );
  }
  /* Put just for reference
  <View style={styles.helpContainer}>
            <TouchableOpacity onPress={this._handleHelpPress} style={styles.helpLink}>
              <Text style={styles.helpLinkText}>Register your pain level here</Text>
            </TouchableOpacity>
          </View>
    <View style={styles.tabBarInfoContainer}>
              <TouchableOpacity onPress={() => this.onImageUploadPress(this.props)} style={styles.helpLink}>
              <Text style={styles.helpLinkText}>Upload Document</Text>
            </TouchableOpacity>
        </View>
  */
  onImageUploadPress(props){
   // console.log('Image Upload Event Handler Called');
    //console.log(this.state);
    //console.log(props);
    //props.navigation.navigate("ImageUpload");
    props.navigation.navigate("ImageDocUploadForm",{"claimNumber":this.state.claimDetails.claim.claimNumber});
   // props.navigation.navigate("ImagePicker");
  }
  onGetAppointmentsPress(props){
      //props.navigation.navigate("Appointments");
   }

  _maybeRenderDevelopmentModeWarning() {
    if (__DEV__) {
      const learnMoreButton = (
        <Text onPress={this._handleLearnMorePress} style={styles.helpLinkText}>
          Learn more
        </Text>
      );

      return (
        <Text style={styles.developmentModeText}>
          Development mode is enabled, your app will be slower but you can use useful development
          tools. {learnMoreButton}
        </Text>
      );
    } else {
      return (
        <Text style={styles.developmentModeText}>
          You are not in development mode, your app will run at full speed.
        </Text>
      );
    }
  }

  _renderNextPayment = () => {
    if (this.state.nextPayment){
      return (
        <View>
             <Text style={styles.optionText}>
                Don't forget. Your Next Payment for {this.state.nextPayment.aAmount} $ is
              </Text>
              <Text style={styles.optionText}>
                due on {this.state.nextPayment.aPaymentDate}
              </Text>
        </View>
      );
    }
    else{
      return(
        <View>
             <Text style={styles.optionText}>
                 You do not have any upcoming
              </Text>
              <Text style={styles.optionText}>
                payments.
              </Text>
        </View>
      );
    }
  };


  _renderNextAppointment = () => {
    if (this.state.nextAppointment){
      return (
        <View>
              <Text style={styles.optionText}>
                Your next Physio appointment 
              </Text>
              <Text style={styles.optionText}>
                is booked on
              </Text>
              <Text style={styles.optionText}>
                  {this.state.nextAppointment.dateTime} with 
              </Text>
              <Text style={styles.optionText}>
               {this.state.nextAppointment.providerName} -
              </Text>
              <Text style={styles.optionText}>
              {this.state.nextAppointment.address.line2},  {this.state.nextAppointment.address.suburb},
              {this.state.nextAppointment.address.state}
              </Text>
        </View>
      );
    }
    else{
      return(
        <View>
             <Text style={styles.optionText}>
                 You do not have any appointments
              </Text>
              <Text style={styles.optionText}>
                scheduled at the moment.
              </Text>
        </View>
      );
    }
  };

  onLoginPress (){
    this.props.screenProps.navigation.navigate("Main",{"claimDetails":this.state.claimDetails})
  }

  _handleLearnMorePress = () => {
    WebBrowser.openBrowserAsync('https://docs.expo.io/versions/latest/guides/development-mode');
  };

  _handleHelpPress = () => {
    /*
    WebBrowser.openBrowserAsync(
      'https://docs.expo.io/versions/latest/guides/up-and-running.html#can-t-see-your-changes'
    );
    */
   this.props.navigation.navigate("RegisterPainLevel",{"claimNumber":this.state.claimDetails.claim.claimNumber});
  };
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  developmentModeText: {
    marginBottom: 20,
    color: 'rgba(0,0,0,0.4)',
    fontSize: 14,
    lineHeight: 19,
    textAlign: 'center',
  },
  contentContainer: {
    paddingTop: 30,
  },
  welcomeContainer: {
    alignItems: 'center',
    marginTop: 5,
    marginBottom: 10,
  },
  welcomeImage: {
    width: 100,
    height: 100,
    resizeMode: 'contain',
    marginTop: 3,
    marginLeft: -10,
  },
  getStartedContainer: {
    alignItems: 'center',
    marginHorizontal: 50,
  },
  homeScreenFilename: {
    marginVertical: 7,
  },
  codeHighlightText: {
    color: 'rgba(96,100,109, 0.8)',
  },
  codeHighlightContainer: {
    backgroundColor: 'rgba(0,0,0,0.05)',
    borderRadius: 3,
    paddingHorizontal: 4,
  },
  getStartedText: {
    fontSize: 17,
    color: 'rgba(96,100,109, 1)',
    lineHeight: 24,
    textAlign: 'center',
  },
  tabBarInfoContainer: {
    bottom: 0,
    left: 0,
    right: 0,
    ...Platform.select({
      ios: {
        shadowColor: 'black',
        shadowOffset: { height: -3 },
        shadowOpacity: 0.1,
        shadowRadius: 3,
      },
      android: {
        elevation: 20,
      },
    }),
    alignItems: 'center',
    backgroundColor: '#fbfbfb',
    paddingVertical: 20,
  },
  tabBarInfoText: {
    fontSize: 17,
    color: 'rgba(96,100,109, 1)',
    textAlign: 'center',
  },
  navigationFilename: {
    marginTop: 5,
  },
  helpContainer: {
    marginTop: 15,
    alignItems: 'center',
  },
  helpLink: {
    paddingVertical: 15,
  },
  helpLinkText: {
    fontSize: 14,
    color: '#2e78b7',
  },
  optionsTC:{
     paddingTop : 50,
  },
  optionsTitleText: {
    fontSize: 16,
    marginLeft: 15,
    marginTop: 9,
    marginBottom: 12,
    textAlign: 'center'
  },
  optionIconContainer: {
    marginRight: 9,
  },
  optionIconContainerR: {
    marginLeft:50,
  },
  option: {
    backgroundColor: '#fdfdfd',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#EDEDED',
  },
  optionText: {
    fontSize: 15,
    marginTop: 1,
  },
  item: {
    backgroundColor: 'white',
    flex: 1,
    borderRadius: 5,
    padding: 10,
    marginRight: 10,
    marginTop: 17
  },
  emptyDate: {
    height: 15,
    flex:1,
    paddingTop: 30
  }
});
