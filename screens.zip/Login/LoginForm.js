import React from 'react';
import { Button, Text , View, TextInput, StyleSheet, TouchableOpacity} from 'react-native';
import MainTabNavigator from '../../navigation/MainTabNavigator';
import {StackNavigator} from 'react-navigation';
import { Permissions, Notifications } from 'expo';


export default class LoginForm extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      claimDetails : {},
       error : "", 
       loading : false,
       deviceToken:"", 
       notification : null, 
       claimNumber:"991900000012",
       businessOperation:"claimIdent"
      };
  }

  componentDidMount(){
    this.registerForPushNotifications();
  }

  async registerForPushNotifications() {
    const { status } = await Permissions.getAsync(Permissions.NOTIFICATIONS);

    if (status !== 'granted') {
      const { status } = await Permissions.askAsync(Permissions.NOTIFICATIONS);
      if (status !== 'granted') {
        return;
      }
    }

    const token = await Notifications.getExpoPushTokenAsync();

    this.subscription = Notifications.addListener(this.handleNotification);

    this.setState({
      deviceToken : token
    });
  }

  handleNotification = notification => {
    this.setState({
      notification,
    });
  };


  render() {

    //console.log(this.props);
    //console.log(this.screenProps);
    return (
      <View style={styles.container}>
         <TextInput
           placeholder="Claim Number"
           placeholderTextColor ="rgba(255,255,255,0.7)"
           returnKeyType = 'go'
           onChangeText = {claimNumber => this.setState({claimNumber})}
           keyboardType = "numbers-and-punctuation"
           style = {styles.input}
         />
         
         <TouchableOpacity style={styles.buttonContainer} onPress={() => this.onLoginPress()}>
            <Text style={styles.buttonText}>LOGIN</Text>
           </TouchableOpacity>
      </View>
    );
  }
  /* For Reference
   <TextInput
           placeholder="Claim Number"
           placeholderTextColor ="rgba(255,255,255,0.7)"
           returnKeyType = 'go'
           ref = {(input)=>this.passwordInput = input}
           onChangeText = {claimNumber => this.setState({claimNumber})}
           keyboardType = "numbers-and-punctuation"
           style = {styles.input}
         />
         <TextInput
           placeholder="Business Operation"
           placeholderTextColor ="rgba(255,255,255,0.7)"
           returnKeyType = 'next'
           onSubmitEditing = {()=>this.passwordInput.focus()}
           onChangeText = {businessOperation => this.setState({businessOperation})}
           autoCapitalize = "none"
           autoCorrect = {false}
           style = {styles.input}
         />
  */
  onLoginPress(){
    //console.log(this.state);
    //this.props.navigation.navigate('Main');
       //this.props.boo();
       fetch('http://192.157.226.106:9876/bin_public/jadehttp.dll/RequestHandler/?WCOnline', {  
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            "businessOperation" : this.state.businessOperation,
            "deviceToken" : this.state.deviceToken,
            "claim" : {
            "claimNumber" : this.state.claimNumber
            }
            })
        }).then((response) => response.json())
        .then((responseJson) => {
          //return responseJson.movies;
          this.setState({claimDetails :responseJson, error :"", loading : false});
          //console.log(this.state.claimDetails);
          this.props.screenProps.navigation.navigate("Main",{"claimDetails":this.state.claimDetails})
        })
        .catch((error) => {
          console.error(error);
        });
    
       
      // console.log("you tapped the thing");
  }

  

}

const styles = StyleSheet.create({
  container: {
    padding: 20,
  },
  input :{
    height : 40,
    backgroundColor :'rgba(255,255,255,0.2)',
    marginBottom: 10,
    color : '#FFF',
    paddingHorizontal: 10,
  },
  buttonContainer : {
    backgroundColor : '#2980b9',
    paddingVertical : 15
  },
  buttonText : {
    textAlign : 'center',
    color : '#FFFFFF',
    fontWeight: '700'
  }
});
