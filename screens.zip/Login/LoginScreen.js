import React from 'react';
import {View, Text, StyleSheet, Image , KeyboardAvoidingView, StatusBar} from 'react-native';
import LoginForm from './LoginForm';


export default class LoginScreen extends React.Component {
  static navigationOptions = {
    header: null,
  };
 
  render() {
    //console.log(this.props); 
    return (
      <KeyboardAvoidingView behavior='padding' style={styles.container}>
          <View style={styles.logoContainer}>
               <StatusBar
                barStyle="light-content"
               />
               <Image 
                style = {styles.logo}
                source ={require('../../assets/images/Allianz_logo.png')}/> 
                <Text style={styles.title}>Injured Workers App Allianz Australia</Text>
                <Text style={styles.title}>v2.7</Text>
          </View>
          <View style={styles.formContainer}>
                <LoginForm screenProps={this.props}/>
          </View>
      </KeyboardAvoidingView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#2c3e50'
  },
  logoContainer : {
      alignItems : 'center',
      flexGrow : 1,
      justifyContent : 'center'
  },
  logo :{
    width : 100,
      height : 100
},
    title:{
        color :'#FFF',
        marginTop : 10,
        width : 140,
        textAlign : 'center',
        opacity : 0.9
    }
});