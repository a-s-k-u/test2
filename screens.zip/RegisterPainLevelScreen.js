import React, { Component } from 'react';
import {    
  StyleSheet,
  Text,
  TextInput,
  View,
  Slider,
  TouchableOpacity,
  KeyboardAvoidingView
} from 'react-native';

export default class RegisterPainLevelScreen extends Component {
  constructor(props) {
   super(props);
   var date = this._getCurrentDate();
   this.state = { painLevel: 1 , notes : "", businessOperation : "claimSubmitJournalEntries", today :date};
  } 

  static navigationOptions = {
    title: "Rate Today's Pain Level",
  };

  getVal(val){
  //console.warn(val);
  }     

  render() {

    return (
         <KeyboardAvoidingView behavior='padding' style={styles.container} >
            <Slider
            style={{ width: 300 }}
            step={1}
            minimumValue={0}
            maximumValue={10}
            value={this.state.painLevel}
            onValueChange={val => this.setState({ painLevel: val })}
            onSlidingComplete={ val => this.getVal(val)}
            />
            <Text style={styles.welcome}>
            {this.state.painLevel}
            </Text>            
            <Text style={styles.instructions}>
            You can mention a bit more,{'\n'}
            regarding your condition right below
            </Text>
            <TextInput
                multiline={true}
                numberOfLines = {4}
                onChangeText = {(notes) => this.setState({notes})}
                value = {this.state.notes}
                placeholder ="My back is killing me today!"
                style = {styles.input}
            />
        <TouchableOpacity style={styles.buttonContainer} onPress={() => this._uploadPainLevel()}>
            <Text style={styles.buttonText}>SUBMIT</Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>
    );
  }

  _uploadPainLevel = () => {
   // alert(this.state.notes);
   // alert(this.state.painLevel);
   var today = new Date();

    fetch('http://192.157.226.106:9876/bin_public/jadehttp.dll/RequestHandler/?WCOnline', {  
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            "businessOperation" : this.state.businessOperation,
            "claim" : {
            "claimNumber" : this.props.navigation.state.params.claimNumber,
             "journalEntries" : [
                 {
                     "dateTime" :this.state.today,
                     "painLevel": this.state.painLevel,
                     "notes" : this.state.notes
                 }
             ]
            }
            })
        }).then((response) => response.json())
        .then((responseJson) => {
          //return responseJson.movies;
          // this.setState({claimDetails :responseJson, error :"", loading : false});
          this.props.navigation.goBack();
        })
        .catch((error) => {
          console.error(error);
        });
   
  }
  _getCurrentDate = () =>{
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth()+1; //January is 0!
    var yyyy = today.getFullYear();   
    if(dd<10) {
        dd = '0'+dd
    } 
    if(mm<10) {
        mm = '0'+mm
    } 
    today = mm + '/' + dd + '/' + yyyy;
    return today;
  }
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  containerSub :{
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
  input :{
    backgroundColor :'rgba(255,255,255,0.2)',
    marginBottom: 10,
    color : '#333333',
    paddingHorizontal: 10,
    width : 300
  },
  buttonContainer : {
    backgroundColor : '#2980b9',
    paddingVertical : 15,
    width : 300,
    bottom: 0,
    left: 0,
    right: 0,
    marginTop :20
  },
  buttonText : {
    textAlign : 'center',
    color : '#FFFFFF',
    fontWeight: '700'
  }
});
