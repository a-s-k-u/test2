import React, { Component } from 'react';
import { ActivityIndicator, View,Platform, ScrollView,Text,StyleSheet,TouchableOpacity ,StatusBar, Image} from 'react-native';
import Touchable from 'react-native-platform-touchable';
import { Ionicons } from '@expo/vector-icons';

export default class ImageDocUploadForm extends Component {

  constructor(props){
    super(props);
    this.state = {
      docType : '',
      dataBase64 :'',
      imageUri :'',
      image: null,
      uploading: false,
    };
  }

  static navigationOptions = {
    title: 'Upload Document',
  };

  render() {
    //console.log('From Image Upload Form');
    //console.log(this.props.navigation.state.params.claimNumber);

    return (
      <View style={styles.container}>
        
        <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
          <View style={styles.welcomeContainer}>
            <Image
              source={
                __DEV__
                  ? require('../../assets/images/MedCert.png')
                  : require('../../assets/images/MedCert.png')
              }
              style={styles.welcomeImage}
            />
          </View>
           
          <Touchable
          style={styles.option}
          background={Touchable.Ripple('#ccc', false)}
          onPress={this._handlePressSelectDocType}>
          <View style={{ flexDirection: 'row' }}>
            <View style={styles.optionTextContainer}>
              <Text style={styles.optionText}>
                Select Doc Type
              </Text>
            </View>
            <View style={styles.optionIconContainer}>
              <Ionicons name="md-arrow-forward" style={{ width: 20, height: 20, marginTop: 1 }}/>
            </View>
          </View>
        </Touchable>
        <View
          style={styles.option}
          background={Touchable.Ripple('#ccc', false)}>
          <View style={{ flexDirection: 'row' }}>
            <View style={styles.optionTextContainer}>
              <Text style={styles.optionText}>
                   {this.state.docType}
              </Text>
            </View>
          </View>
        </View>

        <Touchable
          background={Touchable.Ripple('#ccc', false)}
          style={styles.option}
          onPress={this._handlePressSelectImage}>
          <View style={{ flexDirection: 'row' }}>
            <View style={styles.optionTextContainer}>
              <Text style={styles.optionText}>
                Select Image
              </Text>
            </View>
            <View style={styles.optionIconContainer}>
              <Ionicons name="md-arrow-forward" style={{ width: 20, height: 20, marginTop: 1 }}/>
            </View>
          </View>
        </Touchable>

        <View
          style={styles.option}
          background={Touchable.Ripple('#ccc', false)}>
          <View style={{ flexDirection: 'row' }}>
            <View style={styles.optionTextContainer}>
              <Text style={styles.optionText}>
                   {this.state.dataBase64 ? "Image Selected" : ""}
              </Text>
            </View>
          </View>
        </View>
          
        </ScrollView>

      

        {this._renderUploadButton()}

      <StatusBar barStyle="default" />
      </View>
    );
  }

  _handlePressSelectDocType = () => {
    this.props.navigation.navigate("ImageTypeSelector",{
      onGoBack: (docType) => this.updateDoc(docType),
    });
  };
  _handlePressSelectImage = () => {
    this.props.navigation.navigate("ImageUpload",{
      onGoBack: (imageUri, dataBase64) => this.updateImage(imageUri, dataBase64),
    });
  };
  
  _renderUploadButton = () => {
    if (this.state.uploading){
      return (
        <View>
        <View style={styles.tabBarInfoContainer}>
            <TouchableOpacity style={styles.ahelpLink}>
                 <Text style={styles.ahelpLinkText}>Upload</Text>
            </TouchableOpacity>
        </View>
        <ActivityIndicator color="#0000ff" animating size="large" />
        </View>
      );
    }
    else if((!this.state.docType) || (!this.state.dataBase64)){
      return(
          <View style={styles.tabBarInfoContainer}>
              <TouchableOpacity style={styles.ahelpLink}>
              <Text style={styles.ahelpLinkText}>Upload</Text>
            </TouchableOpacity>
        </View>
      );
    }
    else{
      return(
        <View style={styles.ctabBarInfoContainer}>
              <TouchableOpacity onPress={() => this.onImageUploadPress(this.props)} style={styles.abuttonContainer}>
                  <Text style={styles.helpLinkText}>Upload</Text>
            </TouchableOpacity>
        </View>
      );
    }
  };

  updateDoc(docType) {
    this.setState({docType : docType})
    //console.log(this.state.docType);
    //alert(this.state.docType);
  }

  updateImage(imageUri,dataBase64) {
    //alert(imageUri);
    //console.log(dataBase64);
    this.setState({dataBase64 : dataBase64,imageUri : imageUri});
  }

  onImageUploadPress = async (props) =>{
    let uploadResponse, uploadResult;
    try{
      this.setState({ uploading: true });
      uploadResponse = await uploadImageAsync(this.state.imageUri,this.state.dataBase64,props.navigation.state.params.claimNumber,this.state.docType);
      uploadResult = await uploadResponse.json();
      this.props.navigation.goBack();
      //alert(uploadResult.location);
     // this.setState({ image: uploadResult.location });
    }catch(e){

    }finally{
      this.setState({ uploading: false });
    }
    
  }
}

async function uploadImageAsync(uri,baseSixtyFour,claimNumber,docType) {
  let apiUrl = 'http://192.157.226.106:9876/bin_public/jadehttp.dll/RequestHandler/?WCOnline';
  
  let uriParts = uri.split('.');
  let fileType = uriParts[uriParts.length - 1];
  //alert('claim number is ');
  //alert(claimNumber);
  let formData = new FormData();

  let options = {
    method: 'POST',
    body: JSON.stringify({'businessOperation':'claimDocumentUpload',
    'claim' : {
        'claimNumber' : claimNumber,
         documents : [{
             'fileName' : 'Test.jpg',
             'documentType' : docType,
             'fileData' : baseSixtyFour
         }]
    }
   }),
    headers: {
      Accept: 'application/json',
      'Content-Type': 'multipart/form-data',
    },
  };

  return fetch(apiUrl, options);
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  buttonContainer :{
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  button :{
    backgroundColor: '#2980b9',
    width: '40%',
    height: 40,
  },
  mid :{
    backgroundColor: '#FFF',
    width: '10%',
    height: 40,
  },
  midText : {
    textAlign : 'center',
    color : '#FFFFFF',
    fontWeight: '700'
  },
  buttonText : {
    textAlign : 'center',
    color : '#FFFFFF',
    fontWeight: '700'
  },
  optionsTitleText: {
    fontSize: 16,
    marginLeft: 15,
    marginTop: 9,
    marginBottom: 12,
  },
  optionIconContainer: {
    marginRight: 2,
  },
  option: {
    backgroundColor: '#fdfdfd',
    paddingHorizontal: 15,
    paddingVertical: 15,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#EDEDED',
  },
  optionText: {
    fontSize: 15,
    marginTop: 1,
  },
  item: {
    backgroundColor: 'white',
    flex: 1,
    borderRadius: 5,
    padding: 10,
    marginRight: 10,
    marginTop: 17
  },
  emptyDate: {
    height: 15,
    flex:1,
    paddingTop: 30
  },
  tabBarInfoContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    ...Platform.select({
      ios: {
        shadowColor: 'black',
        shadowOffset: { height: -3 },
        shadowOpacity: 0.1,
        shadowRadius: 3,
      },
      android: {
        elevation: 20,
      },
    }),
    alignItems: 'center',
    backgroundColor: '#fbfbfb',
    paddingVertical: 20,
  },
  tabBarInfoText: {
    fontSize: 17,
    color: 'rgba(96,100,109, 1)',
    textAlign: 'center',
  },
  helpLink: {
    paddingVertical: 15,
  },
  helpLinkActive: {
    paddingVertical: 20,
    backgroundColor: '#fbfbfb',
  },
  ahelpLink: {
    paddingVertical: 20,
  },
  abuttonContainer: {
    paddingVertical: 25,
    backgroundColor : '#2980b9',
  },
  helpLinkText: {
    color : '#FFFFFF',
    fontWeight: '700',
    textAlign : 'center',
  },
  contentContainer: {
    paddingTop: 30,
  },
  welcomeContainer: {
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 20,
  },
  welcomeImage: {
    width: 100,
    height: 80,
    resizeMode: 'contain',
    marginTop: 3,
    marginLeft: -10,
  },
  getStartedContainer: {
    alignItems: 'center',
    marginHorizontal: 50,
  },
  homeScreenFilename: {
    marginVertical: 7,
  },
  codeHighlightText: {
    color: 'rgba(96,100,109, 0.8)',
  },
  codeHighlightContainer: {
    backgroundColor: 'rgba(0,0,0,0.05)',
    borderRadius: 3,
    paddingHorizontal: 4,
  },
  getStartedText: {
    fontSize: 17,
    color: 'rgba(96,100,109, 1)',
    lineHeight: 24,
    textAlign: 'center',
  },
});

