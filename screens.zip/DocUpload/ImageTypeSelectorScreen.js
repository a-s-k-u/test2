import React, { Component } from 'react';
import {  View, Text,StyleSheet,TouchableOpacity,Image } from 'react-native';
import Touchable from 'react-native-platform-touchable';
import { Ionicons } from '@expo/vector-icons';

export default class ImageTypeSelectorScreen extends Component {

    static navigationOptions = {
        title: 'Select Document Type',
    };

    render() {
        return (
          <View>
                       
            <Touchable
              style={styles.option}
              background={Touchable.Ripple('#ccc', false)}
              onPress={this._handlePressMedCert}>
              <View style={{ flexDirection: 'row' }}>
                <View style={styles.optionIconContainer}>
                    <Ionicons name="md-arrow-back" style={{ width: 20, height: 20, marginTop: 1 }}/>
              </View>
                <View style={styles.optionTextContainer}>
                  <Text style={styles.optionText}>
                    MED CERT
                  </Text>
                </View>
              </View>
            </Touchable>
  
          </View>
        );
      }

      _handlePressSlack = () => {
        this.props.navigation.goBack();
      };
    
      _handlePressMedCert = () => {
        this.props.navigation.state.params.onGoBack('MEDCERT');
        this.props.navigation.goBack();
      };
    
      _handlePressForums = () => {
        WebBrowser.openBrowserAsync('http://forums.expo.io');
      };
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      paddingTop: 15,
      backgroundColor: '#fff',
    },
    optionsTitleText: {
      fontSize: 16,
      marginLeft: 15,
      marginTop: 9,
      marginBottom: 12,
    },
    optionIconContainer: {
      marginRight: 9,
    },
    option: {
      backgroundColor: '#fdfdfd',
      paddingHorizontal: 15,
      paddingVertical: 15,
      borderBottomWidth: StyleSheet.hairlineWidth,
      borderBottomColor: '#EDEDED',
    },
    optionText: {
      fontSize: 15,
      marginTop: 1,
    },
    item: {
      backgroundColor: 'white',
      flex: 1,
      borderRadius: 5,
      padding: 10,
      marginRight: 10,
      marginTop: 17
    },
    emptyDate: {
      height: 15,
      flex:1,
      paddingTop: 30
    }
  });
