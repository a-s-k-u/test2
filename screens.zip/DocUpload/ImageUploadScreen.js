import React from 'react';
import {
  ActivityIndicator,
  Button,
  Clipboard,
  Image,
  Share,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Exponent, { Constants, ImagePicker, registerRootComponent } from 'expo';
import Touchable from 'react-native-platform-touchable';
import { Ionicons } from '@expo/vector-icons';

export default class ImageUploadScreen extends React.Component {

    static navigationOptions = {
        title: 'Image Upload',
    };

    state = {
        image: null,
        uploading: false,
    };


    render() {
    let { image } = this.state;
    //md-arrow-forward
    return (
      <View style={styles.container}>
       
            <View style={styles.container}>
              <TouchableOpacity style={styles.button} onPress={this._pickImage}>
                <Text style={styles.buttonText}>
                    Pick an image from camera roll
                </Text>
              </TouchableOpacity>
              <View style={styles.mid}>
                <Text style={styles.midText}>
                    OR
                </Text>
              </View>
              <TouchableOpacity style={styles.button} onPress={this._takePhoto}>
                <Text style={styles.buttonText}>
                    Take a photo
                </Text>
              </TouchableOpacity>
            </View>



        <Button
          onPress={this._pickImage}
          title="Pick an image from camera roll"
        />

        <Button onPress={this._takePhoto} title="Take a photo" />

        {this._maybeRenderImage()}
        {this._maybeRenderUploadingOverlay()}

        <StatusBar barStyle="default" />
      </View>
    );
  }

  
  _maybeRenderUploadingOverlay = () => {
    if (this.state.uploading) {
      return (
        <View
          style={[
            StyleSheet.absoluteFill,
            {
              backgroundColor: 'rgba(0,0,0,0.4)',
              alignItems: 'center',
              justifyContent: 'center',
            },
          ]}>
          <ActivityIndicator color="#fff" animating size="large" />
        </View>
      );
    }
  };

  _maybeRenderImage = () => {
    let { image } = this.state;
    if (!image) {
      return;
    }

    return (
      <View
        style={{
          marginTop: 30,
          width: 250,
          borderRadius: 3,
          elevation: 2,
          shadowColor: 'rgba(0,0,0,1)',
          shadowOpacity: 0.2,
          shadowOffset: { width: 4, height: 4 },
          shadowRadius: 5,
        }}>
        <View
          style={{
            borderTopRightRadius: 3,
            borderTopLeftRadius: 3,
            overflow: 'hidden',
          }}>
          <Image source={{ uri: image }} style={{ width: 250, height: 250 }} />
        </View>

        <Text
          onPress={this._copyToClipboard}
          onLongPress={this._share}
          style={{ paddingVertical: 10, paddingHorizontal: 10 }}>
          {image}
        </Text>
      </View>
    );
  };

  _share = () => {
    Share.share({
      message: this.state.image,
      title: 'Check out this photo',
      url: this.state.image,
    });
  };

  _copyToClipboard = () => {
    Clipboard.setString(this.state.image);
    alert('Copied image URL to clipboard');
  };

  _takePhoto = async () => {
    let pickerResult = await ImagePicker.launchCameraAsync({
      base64: true,
      allowsEditing: true,
      aspect: [4, 3],
    });

    this._handleImagePicked(pickerResult);
  };

  _pickImage = async () => {
    let pickerResult = await ImagePicker.launchImageLibraryAsync({
        base64: true,
      allowsEditing: true,
      aspect: [4, 3],
    });

    this._handleImagePicked(pickerResult);
  };

  _handleImagePicked = async pickerResult => {
    let uploadResponse, uploadResult;

    try {
      this.setState({ uploading: true });

      if (!pickerResult.cancelled) {
        this.props.navigation.state.params.onGoBack(pickerResult.uri, pickerResult.base64);
        this.props.navigation.goBack();
        //uploadResponse = await uploadImageAsync(pickerResult.uri, pickerResult.base64);
        //uploadResult = await uploadResponse.json();
        //this.setState({ image: uploadResult.location });
      }
    } catch (e) {
      console.log({ uploadResponse });
      console.log({ uploadResult });
      console.log({ e });
      alert('Upload failed, sorry :(');
    } finally {
      this.setState({ uploading: false });
    }
  };
}

async function uploadImageAsync(uri,baseSixtyFour) {
  let apiUrl = 'http://192.157.226.106:9876/bin_public/jadehttp.dll/RequestHandler/?WCOnline';

  // Note:
  // Uncomment this if you want to experiment with local server
  //
  // if (Constants.isDevice) {
  //   apiUrl = `https://your-ngrok-subdomain.ngrok.io/upload`;
  // } else {
  //   apiUrl = `http://localhost:3000/upload`
  // }

  let uriParts = uri.split('.');
  let fileType = uriParts[uriParts.length - 1];

  let formData = new FormData();
  /*
  formData.append('photo', {
    uri,
    name: `photo.${fileType}`,
    type: `image/${fileType}`,
  });
  
    formData.append({'businessOperation':'claimDocumentUpload',
     'claim' : {
         'claimNumber' : '991660119081',
          documents : [{
              'fileName' : 'Test',
              'documentType' : 'MEDCERT',
              'fileData' : baseSixtyFour
          }]
     }
    });
    */

   // console.log(formData);

  let options = {
    method: 'POST',
    body: JSON.stringify({'businessOperation':'claimDocumentUpload',
    'claim' : {
        'claimNumber' : '991660119081',
         documents : [{
             'fileName' : 'Test.jpg',
             'documentType' : 'MEDCERT',
             'fileData' : baseSixtyFour
         }]
    }
   }),
    headers: {
      Accept: 'application/json',
      'Content-Type': 'multipart/form-data',
    },
  };

  return fetch(apiUrl, options);
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 15,
    backgroundColor: '#fff',
  },
  buttonContainer :{
    flex: 1,
    flexDirection: 'row',
  },
  button :{
    backgroundColor: '#2980b9',
    width: '40%',
    height: 80,
  },
  mid :{
    backgroundColor: '#FFF',
    width: '10%',
    height: 40,
  },
  midText : {
    textAlign : 'center',
    color : '#FFFFFF',
    fontWeight: '700'
  },
  buttonText : {
    textAlign : 'center',
    color : '#FFFFFF',
    fontWeight: '700'
  },
  optionsTitleText: {
    fontSize: 16,
    marginLeft: 15,
    marginTop: 9,
    marginBottom: 12,
  },
  optionIconContainer: {
    marginRight: 9,
  },
  option: {
    backgroundColor: '#fdfdfd',
    paddingHorizontal: 15,
    paddingVertical: 15,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#EDEDED',
  },
  optionText: {
    fontSize: 15,
    marginTop: 1,
  },
  item: {
    backgroundColor: 'white',
    flex: 1,
    borderRadius: 5,
    padding: 10,
    marginRight: 10,
    marginTop: 17
  },
  emptyDate: {
    height: 15,
    flex:1,
    paddingTop: 30
  }
});
