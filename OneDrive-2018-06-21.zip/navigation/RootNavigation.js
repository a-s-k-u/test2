import { Notifications } from 'expo';
import React from 'react';
import { StackNavigator } from 'react-navigation';

import LoginScreen from '../screens/Login/LoginScreen';
import ImageUploadScreen from '../screens/DocUpload/ImageUploadScreen';
import ImagePickerScreen from '../screens/DocUpload/ImagePickerScreen';
import ImageTypeSelectorScreen from '../screens/DocUpload/ImageTypeSelectorScreen';
import ImageDocUploadForm from '../screens/DocUpload/ImageDocUploadForm';
import RegisterPainLevelScreen from '../screens/RegisterPainLevelScreen';
import LinksScreen from '../screens/LinksScreen';
import MapScreen from '../screens/MapScreen';
import MainTabNavigator from './MainTabNavigator';
import registerForPushNotificationsAsync from '../api/registerForPushNotificationsAsync';

const RootStackNavigator = StackNavigator(
  {
    Login: {
      screen : LoginScreen,
    },
    Main: {
      screen: MainTabNavigator,
    },
    ImageUpload : {
      screen : ImageUploadScreen,
    },
    ImagePicker :{
      screen : ImagePickerScreen,
    },
    ImageTypeSelector : {
      screen : ImageTypeSelectorScreen,
    },
    ImageDocUploadForm : {
      screen : ImageDocUploadForm,
    },
    RegisterPainLevel : {
      screen : RegisterPainLevelScreen,
    },
    Map : {
      screen : MapScreen,
    },
    Appointments : {
      screen : LinksScreen,
    }
  },
  {
    navigationOptions: () => ({
      headerTitleStyle: {
        fontWeight: 'normal',
      },
    }),
  }
);

export default class RootNavigator extends React.Component {
  componentDidMount() {
    this._notificationSubscription = this._registerForPushNotifications();
  }

  componentWillUnmount() {
    this._notificationSubscription && this._notificationSubscription.remove();
  }

  render() {
    return <RootStackNavigator />;
  }

  _registerForPushNotifications() {
    // Send our push token over to our backend so we can receive notifications
    // You can comment the following line out if you want to stop receiving
    // a notification every time you open the app. Check out the source
    // for this function in api/registerForPushNotificationsAsync.js
    registerForPushNotificationsAsync();

    // Watch for incoming notifications
    this._notificationSubscription = Notifications.addListener(this._handleNotification);
  }

  _handleNotification = ({ origin, data }) => {
    console.log(`Push notification ${origin} with data: ${JSON.stringify(data)}`);
  };
}
